import java.util.Scanner;

public class Calculator {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        double a, b, c = 0.0;
        float d, e, f = 0;
        int g = 0;

        System.out.println("Choose the operation: " +
                "\n1.Addition" +
                "\n2.Subtraction" +
                "\n3.Multiplication" +
                "\n4.Division" +
                "\n5.Power" +
                "\n6.Root" +
                "\n7.Percentage" +
                "\n8.Remainder of division" +
                "\n9.Sin, cos, tan" +
                "\n#Please enter the number of operation \n");
        double number = reader.nextDouble();
        double addition = 1;
        double subtraction = 2;
        double multiplication = 3;
        double division = 4 ;
        double power = 5;
        double root = 6;
        double percentage = 7;
        double remainder = 8;
        double sincostan = 9;
        if (number == addition) {
            System.out.print("Enter the first number: ");
            a = reader.nextDouble();
            System.out.print("And enter second: ");
            b = reader.nextDouble();
            c = a + b;
            System.out.printf(a + " + " + b + " = %.4f", c);
        }
        else if (number == subtraction) {
            System.out.print("Enter the first number: ");
            a = reader.nextDouble();
            System.out.print("And enter second: ");
            b = reader.nextDouble();
            c = a - b;
            System.out.printf(a + " - " + b + " = %.4f", c);
        }
        else if (number == multiplication) {
            System.out.print("Enter the first number: ");
            a = reader.nextDouble();
            System.out.print("And enter second: ");
            b = reader.nextDouble();
            c = a * b;
            System.out.printf(a + " * " + b + " = %.4f", c);
        }
        else if (number == division) {
            System.out.print("Enter the first number: ");
            a = reader.nextDouble();
            System.out.print("And enter second: ");
            b = reader.nextDouble();
            c = a / b;
            System.out.printf(a + " / " + b + " = %.4f", c);
        }
        else if (number == power) {
            System.out.print("Enter the number: ");
            a = reader.nextDouble();
            System.out.print("Enhance by: ");
            b = reader.nextDouble();
            c = Math.pow(a, b);
            System.out.printf(a + " power by " + b + " = %.4f", c);
        }
        else if (number == root){
            System.out.print("Write a number: ");
            a = reader.nextDouble();
            c = Math.sqrt(a);
            System.out.printf("Square root of " + a + " = %.4f", c);
        }
        else if (number == percentage){
            System.out.print("Enter the full number: ");
            d = reader.nextFloat();
            System.out.print("Now enter the fraction: ");
            e = reader.nextFloat();
            f = e * 100 / d;
            System.out.println(f + "%");
        }
        else if (number == remainder) {
            System.out.print("Enter the first number: ");
            a = reader.nextDouble();
            System.out.print("And enter second: ");
            b = reader.nextDouble();
            c = a % b;
            System.out.println("Remainder of " + a + " / " + b + " = " + c);
        }
        else if (number == sincostan) {
            System.out.println("1.Sin, 2.Cos or 3.Tan?");
            g = reader.nextInt();
            System.out.print("Enter the number: ");
            a = reader.nextDouble();
            if (g == 1){
                c = Math.sin(a);
                System.out.printf("Sin of " + a + " = %.4f", c);
            } else if (g == 2) {
                c = Math.cos(a);
                System.out.printf("Cos of " + a + " = %.4f", c);
            } else if (g == 3) {
                c = Math.tan(a);
                System.out.printf("Tan of " + a + " = %.4f", c);
            }
        }
        else System.out.println("Number added is invalid.\nPlease restart the application and choose operation between 1 and 5.");
    }
}
